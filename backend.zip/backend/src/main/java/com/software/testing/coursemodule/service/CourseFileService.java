package com.software.testing.coursemodule.service;

import com.software.testing.common.Result;
import org.springframework.web.multipart.MultipartFile;

public interface CourseFileService {
    /** 上传课程资源文件 */
    Result<?> uploadFile(Long courseId, Long teacherId, MultipartFile file);
    /** 获取课程资源文件列表 */
    Result<?> getFiles(Long courseId);
    /** 删除课程资源文件 */
    Result<?> deleteFile(Long fileId, Long userId);
}
