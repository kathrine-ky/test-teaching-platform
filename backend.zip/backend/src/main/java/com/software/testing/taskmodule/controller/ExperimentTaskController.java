package com.software.testing.taskmodule.controller;

import com.software.testing.common.Result;
import com.software.testing.taskmodule.dto.TaskQueryDTO;
import com.software.testing.taskmodule.entity.ExperimentTask;
import com.software.testing.taskmodule.service.ExperimentTaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/api/task")
public class ExperimentTaskController {

    @Autowired
    private ExperimentTaskService taskService;

    @PostMapping("/create")
    public Result<?> create(@RequestBody ExperimentTask task, HttpServletRequest request) {
        task.setTeacherId((Long) request.getAttribute("userId"));
        return taskService.createTask(task);
    }

    @PutMapping("/update")
    public Result<?> update(@RequestBody ExperimentTask task) {
        return taskService.updateTask(task);
    }

    @DeleteMapping("/{taskId}")
    public Result<?> delete(@PathVariable Long taskId) {
        return taskService.deleteTask(taskId);
    }

    @GetMapping("/{taskId}")
    public Result<?> detail(@PathVariable Long taskId) {
        return taskService.getTaskDetail(taskId);
    }

    @PostMapping("/list")
    public Result<?> list(@RequestBody TaskQueryDTO query, HttpServletRequest request) {
        Long userId = (Long) request.getAttribute("userId");
        String role = (String) request.getAttribute("role");
        return taskService.listTasks(query, userId, role);
    }

    @PutMapping("/publish/{taskId}")
    public Result<?> publish(@PathVariable Long taskId) {
        return taskService.publishTask(taskId);
    }

    /** 撤回已发布任务（改回草稿） */
    @PutMapping("/withdraw/{taskId}")
    public Result<?> withdraw(@PathVariable Long taskId) {
        return taskService.withdrawTask(taskId);
    }

    /** 上传任务附件（测试用例模板、环境说明文档等） */
    @PostMapping("/{taskId}/file/upload")
    public Result<?> uploadFile(@PathVariable Long taskId,
                                @RequestParam("file") MultipartFile file) {
        return taskService.uploadTaskFile(taskId, file);
    }

    /** 获取任务附件列表 */
    @GetMapping("/{taskId}/files")
    public Result<?> getFiles(@PathVariable Long taskId) {
        return taskService.getTaskFiles(taskId);
    }

    /** 删除任务附件 */
    @DeleteMapping("/file/{fileId}")
    public Result<?> deleteFile(@PathVariable Long fileId) {
        return taskService.deleteTaskFile(fileId);
    }
}
